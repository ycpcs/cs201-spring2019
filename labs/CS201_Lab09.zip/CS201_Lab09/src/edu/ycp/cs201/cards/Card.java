package edu.ycp.cs201.cards;

public class Card {
	// TODO - add fields an methods
}
